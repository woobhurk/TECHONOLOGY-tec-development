vagrant up
pause>NUL
